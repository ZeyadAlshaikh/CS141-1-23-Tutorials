public class BasePlusCommissionEmployee  extends CommissionEmployee{
    private double salary;

    public BasePlusCommissionEmployee(String firstName, String lastName, String socailSecurityNumber,
            double grossSalary, double commissionRate, double salary) {
                
        super(firstName, lastName, socailSecurityNumber, grossSalary, commissionRate);
        System.out.println("BasePlusCommissionEmployee Constructor");
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    } 

    @Override
    public double earnings(){
        return salary + super.earnings();
    }

    @Override
    public String toString(){
        return super.toString() + "Salary = "+ salary;
    }

    // @Override
    // private void access(){// worng 

    // }

    @Override
    public void access(){
        
        Object obj;
        

    }
    
}
