public class CommissionEmployee{
    private final String firstName;
    private final String lastName; 
    private final String socailSecurityNumber; 
    private double grossSalary;
    private double commissionRate;
    
    public CommissionEmployee(String firstName, String lastName, String socailSecurityNumber, double grossSalary,
            double commissionRate) {
                System.out.println("CommissionEmployee Constructor");
        this.firstName = firstName;
        this.lastName = lastName;
        this.socailSecurityNumber = socailSecurityNumber;
        this.grossSalary = grossSalary;
        this.commissionRate = commissionRate;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSocailSecurityNumber() {
        return socailSecurityNumber;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    public double earnings(){
        return grossSalary * commissionRate;
    }

    @Override
    public String toString() {
        return "CommissionEmployee [firstName=" + firstName + ", lastName=" + lastName + ", socailSecurityNumber="
                + socailSecurityNumber + ", grossSalary=" + grossSalary + ", commissionRate=" + commissionRate + "]";
    } 

    protected void access(){
        
    }

    
    

    
}