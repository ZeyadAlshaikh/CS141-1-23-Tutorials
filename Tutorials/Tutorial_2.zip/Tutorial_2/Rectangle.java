//package Tutorials.Tutorial_2;

public class Rectangle {
    private double length = 1 , width = 1; 
    private final double  MIN = 0.0, MAX = 20.0;
    /*
     TODO:
        Create constructor that takes as parameter another object of type Rectangle2
    TODO:
        allow the user to initiate the min and max values
     */

    

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    public Rectangle() {
    }
    public double getLength() {
        return length;
    }
    public void setLength(double length) {
        this.length = length;
    }
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        this.width = width;
    }
    public double getMIN() {
        return MIN;
    }
    public double getMAX() {
        return MAX;
    } 

    public double perimeter(){
        return (length + width) * 2; 
    }

    public double area(){
        return length * width; 
    }
    @Override
    public String toString() {
        return "Rectangle [length=" + length + ", width=" + width + ", MIN=" + MIN + ", MAX=" + MAX + " perimeter = "+perimeter()+" area= "+area()+"]";
    }

    
    

}
