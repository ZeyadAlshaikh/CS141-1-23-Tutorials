//package Tutorials.Tutorial_2;

public class Rectangle2 {
    private double length = 1 , width = 1; 
    private final double  MIN , MAX ;
    

    

    public Rectangle2(double length, double width, double max, double min) {
        if (length < max && length > min )
            this.length = length;
        if (width < max && width > min )
            this.width = width;
        
        this.MAX = max; 
        this.MIN = min;
    }
    public Rectangle2(double length, double width) {
        this(length,width,20,0);
        
    }

    public Rectangle2( Rectangle2 rt){
        this(rt.length, rt.width,rt.MAX, rt.MIN);
    }
    public Rectangle2() {
        this(1,1,20,0);
    }
    public double getLength() {
        return length;
    }
    public void setLength(double length) {
        if (length < MAX && length > MIN )
            this.length = length;
    }
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        if (width < MAX && width > MIN )
            this.width = width;
    }
    public double getMIN() {
        return MIN;
    }
    public double getMAX() {
        return MAX;
    } 

    public double perimeter(){
        return (length + width) * 2; 
    }

    public double area(){
        return length * width; 
    }
    @Override
    public String toString() {
        return "Rectangle2 [length=" + length + ", width=" + width + ", MIN=" + MIN + ", MAX=" + MAX + " perimeter = "+perimeter()+" area= "+area()+"]";
    }

    
    

}
