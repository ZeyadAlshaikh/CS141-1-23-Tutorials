//package Tutorials.Tutorial_2;

public class Tester {
    public static void main(String[] args) {
        Rectangle rt1 = new Rectangle(10, 7);
        System.out.printf("%s%n", rt1);

        Rectangle2 rt2 = new Rectangle2();
        Rectangle2 rt3 = new Rectangle2(4,6);
        Rectangle2 rt4 = new Rectangle2(14,6,10,3);
        Rectangle2 rt5 = new Rectangle2(rt3);

        System.out.println(rt2);
        System.out.println(rt3);
        System.out.println(rt4);
        System.out.println(rt5);


    }
}
